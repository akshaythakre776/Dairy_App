import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { ChartsModule } from 'ng2-charts'
import { HttpClientModule } from '@angular/common/http';
import { NotificationComponent } from './notification/notification.component';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { AreaComponent } from './area/area.component';
import { CustomerComponent } from './customer/customer.component';





const appRoutes: Routes = [
  {path: '',redirectTo: 'home',pathMatch: 'full'},
  { path: 'home', component: HomeComponent},
  { path: 'notification', component: NotificationComponent },
  { path: 'area', component: AreaComponent },
  { path: 'customer', component: CustomerComponent },
];


@NgModule({
  declarations: [
    AppComponent,
    NotificationComponent,
    HomeComponent,
    AreaComponent,
    CustomerComponent

  ],
  imports: [
    RouterModule.forRoot(
      appRoutes,
      { enableTracing: true } // <-- debugging purposes only
    ),
        
    BrowserModule,
    ChartsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
